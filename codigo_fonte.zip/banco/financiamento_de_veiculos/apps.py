from django.apps import AppConfig


class FinanciamentoDeVeiculosConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "financiamento_de_veiculos"
